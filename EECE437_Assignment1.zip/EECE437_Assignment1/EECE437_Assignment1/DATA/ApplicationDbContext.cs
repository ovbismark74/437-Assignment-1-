﻿using Microsoft.EntityFrameworkCore;
using EECE437_Assignment1.Models; // Replace with your actual namespace

public class ApplicationDbContext : DbContext
{
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
        : base(options)
    { }

    public DbSet<Product> Products { get; set; }
    public DbSet<Category> Categories { get; set; }
    public DbSet<Customer> Customers { get; set; }
    public DbSet<Order> Orders { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        modelBuilder.Entity<Category>().HasData(
            new Category { CategoryId = 1, Name = "Electronics" },
            new Category { CategoryId = 2, Name = "Clothing" },
            new Category { CategoryId = 3, Name = "Books" }
        );

        modelBuilder.Entity<Product>().HasData(
            new Product { ProductId = 1, Name = "Laptop", Price = 1200.00m, CategoryId = 1 },
            new Product { ProductId = 2, Name = "T-Shirt", Price = 25.99m, CategoryId = 2 },
            new Product { ProductId = 3, Name = "C# Programming Book", Price = 39.99m, CategoryId = 3 }
        );



        modelBuilder.Entity<Customer>().HasData(
        new Customer { CustomerId = 1, Name = "John Doe", Email = "john.doe@example.com" },
        new Customer { CustomerId = 2, Name = "Jane Smith", Email = "jane.smith@example.com" },
        new Customer { CustomerId = 3, Name = "Alice Johnson", Email = "alice.johnson@example.com" },
        new Customer { CustomerId = 4, Name = "Bob Brown", Email = "bob.brown@example.com" },
        new Customer { CustomerId = 5, Name = "Charlie Williams", Email = "charlie.williams@example.com" }
    );


        modelBuilder.Entity<Order>().HasData(
            new Order { OrderId = 1, CustomerId = 1, OrderDate = DateTime.Parse("2024-03-01") },
            new Order { OrderId = 2, CustomerId = 2, OrderDate = DateTime.Parse("2024-03-02") },
            new Order { OrderId = 3, CustomerId = 3, OrderDate = DateTime.Parse("2024-03-03") },
            new Order { OrderId = 4, CustomerId = 4, OrderDate = DateTime.Parse("2024-03-04") },
            new Order { OrderId = 5, CustomerId = 5, OrderDate = DateTime.Parse("2024-03-05") }
        );
    }
}
